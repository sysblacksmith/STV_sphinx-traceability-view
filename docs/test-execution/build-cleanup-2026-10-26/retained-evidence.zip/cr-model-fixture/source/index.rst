CR lifecycle chart fixture
============================

.. change_request:: Draft request
   :id: FIX_CR_001
   :status: draft
   :basis: owner
   :evidence: fixture
   :priority: unassigned
   :verification_state: not_assessed

   Fixture request.

.. change_request:: Accepted request
   :id: FIX_CR_002
   :status: accepted
   :basis: owner
   :evidence: fixture
   :priority: unassigned
   :verification_state: not_assessed

   Fixture request.

.. change_request:: Implemented request
   :id: FIX_CR_003
   :status: implemented
   :basis: owner
   :evidence: fixture
   :priority: unassigned
   :verification_state: not_assessed

   Fixture request.

.. status-pie:: change_request

Total: :need_count:`type == "change_request"`

.. status-pie:: test_case

Empty total: :need_count:`type == "test_case"`
