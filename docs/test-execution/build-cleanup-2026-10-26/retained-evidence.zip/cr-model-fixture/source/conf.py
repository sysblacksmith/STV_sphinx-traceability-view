import sys
sys.path.insert(0,'D:\\Dropbox\\MikroContr_Projects\\-agents\\skills\\reverse-engineer-requirements\\scripts')
import traceability_model as m
extensions=["sphinx_needs","status_charts"]
needs_types=m.NEEDS_TYPES
needs_links=m.NEEDS_LINKS
needs_fields=m.NEEDS_FIELDS
needs_build_json=True
