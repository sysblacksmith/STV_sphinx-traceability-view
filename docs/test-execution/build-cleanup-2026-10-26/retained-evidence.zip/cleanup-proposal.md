# Proposed cleanup

No deletion has been performed. Sizes are logical file sizes.

| Exact project-relative path | MiB | Reason |
|---|---:|---|
| `docs/_build/.html-doctrees-00be74f2d9284858968857590e6cf69b` | 12.24 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-027b258bb32b4b258ec68a65bdd42023` | 13.21 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-14af18b44526496980ab7b14431da9fd` | 15.63 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-18937aa134fb4a9da99b8c9cc26a554a` | 12.18 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-2267fbae809048319cfb5b4ba1875d8c` | 14.44 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-226fffcab9774f9c89cf4aa523a7a8eb` | 12.17 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-277178e858f84026974444c7e841511f` | 12.77 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-2997417e7a964bf48a39afc63ec65393` | 12.26 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-2b78867748c946f2afc123dc05958daa` | 12.27 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-2da429857fb447b1a24940b8442fc6bb` | 14.46 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-2f5ffca7ecac4b309fc14ea9b0b9ddc0` | 12.25 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-34b7a4adf2ed453e9a542638170cae42` | 13.21 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-381766c31d124c61abab203bed6cc311` | 13.87 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-3cc27e7aee0f485dab42de2baecd59f5` | 14.50 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-41ee01bbc813422ea58cfab7689d33a0` | 12.89 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-471c172d9b124edb957b1aaad9d9ff03` | 13.03 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-4f8774033f914490ae229fccea27e474` | 11.28 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-4fcb980d953b453f87ffdd853cc20626` | 12.18 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-5943f58c28ed460eb00d2b7d8117adbd` | 12.24 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-6af4af8254bb4b0cabeb6b424f7c60a1` | 12.43 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-724f2b084b5b44eeaa78c6c848d10e7b` | 14.50 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-8885d9a9ab834eefb51d08b9ad455dc1` | 12.77 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-8f98552f6bfc4c0e88c7b2c1a4152aac` | 14.46 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-909b4cf4dc504aeda0d1b3487ccc93c8` | 12.60 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-944a2f98ada6444c9c5857e50efec2f5` | 11.28 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-9d81a88f53aa40428ea675873cac7f2d` | 12.27 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-9f56d6c7372040d3a4b51f86b3deef84` | 12.44 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-a6aeb7dff6c04533819762de8d273d34` | 12.59 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-afa9403098644cf2bd470818561da45f` | 12.17 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-b2568ddf5c124d85b42c1bb5e4d27927` | 12.79 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-b28f2ee09b9a4f83bb0fbe8fbba02a6e` | 12.17 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-bb3efaf2845e47e991d45ead6c1fa8c2` | 12.88 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-bde3938bcae644d4905c61f17542ada3` | 12.27 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-c617008d63b340a2ac6ebc68d474a900` | 12.18 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-cedf8fb4629b4556a13c1658dd048486` | 12.44 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-d05d37e0db294a518ee826bb9ded8000` | 13.88 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-d6e53f2f6a9a41aa99282014dd39c754` | 12.22 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-d7b7a088ec554a5e97d8e270b6ed62cb` | 13.04 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-d7cb585a5e1c4e2d88484e2fb162e725` | 12.18 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-dad49e46ea644845a9006daafc2df1d0` | 12.17 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-dfcd48dbe38e48808665b5da3c42098d` | 12.65 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-e03a86c9d58f46e3ac66862db14496f9` | 12.45 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-f39b6abff9804c168624234ecc8eb933` | 13.00 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-doctrees-f7168b771cde4be0b36b95b1f7b55e5f` | 15.61 | Reproducible Sphinx doctree cache; fresh builds regenerate it. |
| `docs/_build/.html-previous-0bec88ac47c54d938df95514f399b263` | 47.15 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-18518ad6e0ac45b2a29584397263d408` | 49.89 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-1f06d528c7a64fecb27f107986f0bd88` | 53.25 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-25e892ca45ff4fcdaa3ce8e97fea1a10` | 64.40 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-333af0d0952c4f1b92d4d4a13e19cee0` | 59.87 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-385e98279b3a477c8b5e601c007d710d` | 48.65 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-4e961b15996a48f98a1e5ea651b4dfd4` | 55.38 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-542bda4a3ba74938828dcff73652bdfd` | 97.66 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-5436d3fa311643c3b793397c6ca43607` | 47.71 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-557684412fd54010bd627f4f9cdd38d4` | 51.75 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-573035bcff4a4fb09027f85bfc3d2a71` | 48.00 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-672bf1e14b9849f189af0c6c946c48f5` | 49.55 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-6a88169d3359496e894cad25adc16fce` | 47.69 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-6abdfdfa782b46c0a014064a95a64bbc` | 48.85 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-7373702c3d81442491501672b4ef9b07` | 47.78 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-7f8b30ca46974a83b38fa45d741c84b3` | 59.87 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-81f7a6e299b04c5e88a34300c91d1526` | 58.21 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-8fac9e42077c4a249f170e8828347506` | 75.87 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-9109201207d34678a20232b6c7bbc46a` | 47.18 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-919c3e33949843e8a3ae0ff6b3123490` | 47.42 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-92cb69b436cb441d94e3827639a71c52` | 47.05 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-97a025c57f224242bc01e12ea809611a` | 49.83 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-9a18da4c028f465f9f0ce89b49e5b428` | 47.62 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-ac202f1b7ef04b908a21647b63f42c8b` | 59.94 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-adc460622caf4e29b53ce54dd2ba5f18` | 51.40 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-adca989362194103acbaca13957c9fcf` | 50.57 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-af54b21cd00148e8bbc2c4e44536be81` | 51.84 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-b2bb855d4cd8407faa4dccaafe4d3b57` | 44.83 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-b3e1fd7f3a6a489fbfa9c1c66d417471` | 47.15 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-c6eb05fcc39a4e8c9d3eee68e9aa1e03` | 47.52 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-caff97beed7f4cd5ba984c6720ae06a1` | 47.15 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-ce2db4bc62094fb198253cefcc703f1c` | 47.69 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-e7f42be73c3a44c39274a1b202ad5f37` | 47.13 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-ea0cc350b3e84cfbb8ccc1547d4b5ee9` | 56.57 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-f08bf5b12b2048c194b3c44de8b55b32` | 47.77 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-f214b8cd1a3e4409b3ecd482e3b222a6` | 47.99 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-f2d5ab8696f04a72b4e3789f773cd860` | 44.70 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-f91798dc951b41b6ae90ae77174c0540` | 47.15 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-fb81fbdaa28a4c3fbbb51894c5c61f4c` | 52.79 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-fcf64fdad33b4077b7868951469a961f` | 47.99 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/.html-previous-fd25f1fee9df4bf98e724d54132d0ec8` | 47.13 | Superseded rendered HTML backup; canonical release evidence and archives are retained. |
| `docs/_build/cr013-benchmark` | 410.62 | Reproducible benchmark fixture; measurements and release evidence remain retained. |
| `docs/_build/cr014-benchmark` | 410.62 | Reproducible benchmark fixture; measurements and release evidence remain retained. |
| `docs/_build/pr013-benchmark` | 410.62 | Reproducible benchmark fixture; measurements and release evidence remain retained. |
| `docs/_build/release-source` | 141.30 | Temporary staged-source validation copy; Git commit and canonical evidence retain the source. |

Total: 3.98 GiB.

Retain current docs/_build/html, dist/, docs/test-execution/, release-benchmark, active environments/tooling/wheelhouse/browser tools. Failed stages and other diagnostic outputs are excluded pending a separate review. Removing old benchmarks requires rebuilding their fixtures before reuse (the latest comparable build took about 4.4 minutes).
