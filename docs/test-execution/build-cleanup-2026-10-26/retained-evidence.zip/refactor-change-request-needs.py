from pathlib import Path
import re

root=Path(__file__).resolve().parents[2]
shared=root.parent/'-agents'
scripts=shared/'skills/reverse-engineer-requirements/scripts'
p=scripts/'traceability_model.py';t=p.read_text(encoding='utf-8')
t=t.replace('eight-type','nine-type')
t=t.replace("PROBLEM_REPORT_STATES = ['new', 'analyzed', 'fixed']","PROBLEM_REPORT_STATES = ['new', 'analyzed', 'fixed']\nCHANGE_REQUEST_STATES = ['draft', 'accepted', 'implemented']",1)
t=t.replace("NEEDS_STATUSES_BY_TYPE['problem_report'] = PROBLEM_REPORT_STATES","NEEDS_STATUSES_BY_TYPE['problem_report'] = PROBLEM_REPORT_STATES\nNEEDS_STATUSES_BY_TYPE['change_request'] = CHANGE_REQUEST_STATES",1)
t=t.replace('NEEDS_TYPES = [','NEEDS_TYPES = [\n    dict(directive=\'change_request\', title=\'Change request\', prefix=\'CR_\', color=\'#E7EDF8\', style=\'node\'),',1)
t=t.replace("REVIEW_STATES + PROBLEM_REPORT_STATES + ['recorded']","list(dict.fromkeys(REVIEW_STATES + PROBLEM_REPORT_STATES + CHANGE_REQUEST_STATES + ['recorded']))",1)
p.write_text(t,encoding='utf-8')
p=scripts/'validate_traceability.py';t=p.read_text(encoding='utf-8').replace("'problem_report': (),","'problem_report': (),\n        'change_request': (),",1).replace("('sysr', 'problem_report', 'test_case', 'test_execution')","('sysr', 'problem_report', 'change_request', 'test_case', 'test_execution')",1);p.write_text(t,encoding='utf-8')

# Use the same canonical Need population and standard count role as all charts.
p=scripts/'status_charts.py';t=p.read_text(encoding='utf-8')
t=t.replace('from pathlib import PurePosixPath\nimport re\n','').replace('from sphinx.errors import SphinxError\n','')
start=t.index('\n\nCHANGE_REQUEST_STATES =');end=t.index('\n\nclass StatusPie(',start);t=t[:start]+t[end:]
start=t.index('\n\nclass StatusTotal(');end=t.index('\n\nclass StatusPieDirective',start);t=t[:start]+t[end:]
t=t.replace('    node_type = StatusPie\n','',1)
t=t.replace("if kind not in NEEDS_STATUSES_BY_TYPE and kind != 'change_request':","if kind not in NEEDS_STATUSES_BY_TYPE:",1)
t=t.replace("        if kind == 'change_request' and 'tag' in self.options:\n            raise self.error('Change-request status charts do not support Need tags')\n",'')
t=t.replace('node = self.node_type(kind=kind,','node = StatusPie(kind=kind,',1)
start=t.index('\n\nclass StatusTotalDirective');end=t.index('\n\ndef render_status_charts',start);t=t[:start]+t[end:]
t=t.replace('list(doctree.findall(lambda node: isinstance(node, (StatusPie, StatusTotal))))','list(doctree.findall(StatusPie))')
start=t.index("        if kind == 'change_request':");end=t.index('        if not total:',start)
t=t[:start]+'''        statuses = NEEDS_STATUSES_BY_TYPE[kind]
        counts = Counter(need['status'] for need in needs.values()
                         if need['type'] == kind
                         and (tag is None or tag in need.get('tags', [])))
        total = sum(counts.values())
'''+t[end:]
t=t.replace(", unclassified='#888888'",'')
t=t.replace("    app.add_directive('status-total', StatusTotalDirective)\n",'').replace("    app.add_config_value('status_chart_change_request_root', 'change-requests', 'env', types=[str])\n",'')
p.write_text(t,encoding='utf-8')

# Preserve document labels/filenames. Embed all historical prose in each Need;
# section headings become rubrics because Need bodies cannot nest sections.
for p in (root/'docs/change-requests').glob('STV_CR_*.rst'):
    text=p.read_text(encoding='utf-8');lines=text.splitlines();identity=re.search(r'STV_CR_[0-9]+',p.name)[0]
    for i,line in enumerate(lines):
        if i and re.fullmatch(r'=+',line) and lines[i-1].strip():
            title=lines[i-1];head='\n'.join(lines[:i+1]);body='\n'.join(lines[i+1:]);break
    else:raise ValueError(p)
    body=re.sub(r'^:change_request_status:.*\n?', '', body, flags=re.M).strip()
    body=re.sub(r'^([^\s].*)\n[-=~^]{3,}\s*$',r'.. rubric:: \1',body,flags=re.M)
    basis='documented' if identity=='STV_CR_001' else 'owner'
    metadata=f'''.. change_request:: {title}
   :id: {identity}
   :status: implemented
   :basis: {basis}
   :evidence: {p.relative_to(root).as_posix()}
   :priority: unassigned
   :verification_state: not_assessed

'''
    p.write_text(head+'\n\n'+metadata+'\n'.join('   '+line if line else '' for line in body.splitlines())+'\n',encoding='utf-8')

for p in (root/'docs/project-metrics.rst',shared/'skills/reverse-engineer-requirements/assets/sphinx/project-metrics.rst'):
    t=p.read_text(encoding='utf-8').replace('use Draft / Accepted / Implemented metadata on their source documents;\nUnclassified identifies records without explicit status. These lifecycles','use their canonical Draft / Accepted / Implemented Need status. These lifecycles')
    t=t.replace('      .. status-total:: change_request',"      **Total:** :need_count:`type == 'change_request'`")
    p.write_text(t,encoding='utf-8')
p=root/'docs/conf.py';t=p.read_text(encoding='utf-8').replace("'unclassified_tests', 'problems',","'unclassified_tests', 'problems', 'changes',",1).replace("traceability_view_model['types']['problem_report'] = {'level': 'problems'}","traceability_view_model['types']['problem_report'] = {'level': 'problems'}\ntraceability_view_model['types']['change_request'] = {'level': 'changes'}",1);p.write_text(t,encoding='utf-8')
p=root/'docs/change-requests/index.rst';t=p.read_text(encoding='utf-8');at=t.index('.. toctree::');t=t[:at]+'''Each request is a ``change_request`` Need with Draft / Accepted / Implemented
status. Implementation status describes completed agreed scope; requirement
acceptance, verification and release approval remain separate.

.. needtable::
   :filter: type == 'change_request'
   :columns: id;title;status

'''+t[at:];p.write_text(t,encoding='utf-8')

p=shared/'method.md';t=p.read_text(encoding='utf-8').replace('## Eight types','## Nine types').replace('| `problem_report` | User-reported issue and its resolution handover | `PRJ_PR_001` |','| `problem_report` | User-reported issue and its resolution handover | `PRJ_PR_001` |\n| `change_request` | Owner request, scoped acceptance and implementation lifecycle | `PRJ_CR_001` |',1)
t=t.replace('in an ordinary RST amendment linked from the Miscellaneous maturity page','in a `change_request` Need in the canonical change-request document, linked from the Miscellaneous maturity page',1)
start=t.index('\n\n## Change-request lifecycle metrics');t=t[:start]+'''

## Change-request lifecycle and metrics

Use one `.. change_request::` Need per canonical CR document, with the stable
`<PROJECT>_CR_<number>` ID, title, status, basis, evidence, priority and independent
verification_state fields. Preserve the original request, date/provenance,
scope, owner decisions, affected Need/doc links and implementation context in
its body. Use rubrics for internal headings inside the Need. Preserve existing
document filenames and legacy RST labels during migration; canonical cross-links
can use `:need:`. Never invent missing owner wording or acceptance evidence.

CR status uses exactly **draft**, **accepted**, **implemented**. Draft means
recorded/proposed intent; accepted requires actual owner approval of the agreed
request; implemented requires completion of that agreed work. Status does not
accept linked requirements, establish full verification or approve a release.
Update the canonical Need status from actual evidence and keep dated review/
implementation history centrally in maturity/review. Existing historical prose
and execution histories remain unchanged during migration.

Change requests are optional scope-management records outside mandatory
requirement derivation/allocation, just like problem reports. Reference affected
Needs/documents in their bodies; do not use a CR as a requirement parent, an
architecture allocation or a test verification target. The validator enforces
their own status enum and rejects those illegal typed relations. Missing status
is invalid; do not invent an Unclassified canonical state or parse prose.

Metrics has a Scope management status subsection with separate canonical
`problem_report` (new/analyzed/fixed) and `change_request`
(draft/accepted/implemented) pies and matching `need_count` totals. Charts read
exported Needs, not document metadata, filenames or Git stashes. Existing projects
without CRs remain valid and display the no-data message/zero total. Ordinary
release instructions belong in maturity, not the CR register.
'''
p.write_text(t,encoding='utf-8')
p=shared/'skills/reverse-engineer-requirements/references/documentation-layout.md';t=p.read_text(encoding='utf-8');start=t.index('\n\n## Scope-management metrics and change-request status');t=t[:start]+'''

## Scope-management metrics and change-request status

Metrics contains nine charts: the seven requirement/element/test-case charts
plus a **Scope management status** subsection with problem tickets and change
requests. Use `status-pie:: problem_report` and `status-pie:: change_request`,
with matching `need_count` predicates for the same canonical types. Problem
states remain new/analyzed/fixed; CR states are draft/accepted/implemented.
Both types are real Sphinx-Needs records with the common metadata defined in
the shared method, outside mandatory requirement allocation/coverage.

Use one `.. change_request::` per existing CR file; preserve stable IDs and
filenames and retain legacy document labels on migration. Its body preserves
the complete originating request and context; use rubrics instead of nested
section headings. Do not infer lifecycle states from prose or passing tests.
Do not create duplicate ordinary-document status fields or an Unclassified
Need state. Empty populations render the no-data message and zero count.
Add a CR needtable to the Change Requests index. The adjacent
`change-requests/request.rst.template` is a non-instantiated starter.
CR colors use gold for Draft, blue for Accepted and green for Implemented.
Keep nine charts at the shared 80% linear display size with responsive rows.
Tagged chart populations use distinct safe SVG filenames.
''';p.write_text(t,encoding='utf-8')
p=shared/'skills/reverse-engineer-requirements/assets/sphinx/change-requests/index.rst';p.write_text('''Change Requests
===============

No records have been authored yet. Use ``request.rst.template`` to create a
real ``change_request`` Need when an owner request is recorded. Retain stable
IDs, provenance and the Draft / Accepted / Implemented lifecycle defined by
the shared method. These records feed :doc:`../project-metrics`.

.. needtable::
   :filter: type == 'change_request'
   :columns: id;title;status
''',encoding='utf-8')
p=shared/'skills/reverse-engineer-requirements/assets/sphinx/change-requests/request.rst.template';p.write_text('''{{PROJECT}}_CR_001: {{TITLE}}
======================================

.. change_request:: {{TITLE}}
   :id: {{PROJECT}}_CR_001
   :status: draft
   :basis: owner
   :evidence: docs/change-requests/{{PROJECT}}_CR_001_{{slug}}.rst
   :priority: unassigned
   :verification_state: not_assessed

   .. rubric:: Owner request and provenance

   Record the actual request, date and source; disclose missing information.

   .. rubric:: Scope and affected artifacts

   Record affected Need/doc links, retained constraints and pending decisions.
''',encoding='utf-8')
p=shared/'skills/manage-change/SKILL.md';t=p.read_text(encoding='utf-8');start=t.index('\n\n## Change-request lifecycle metadata');t=t[:start]+'''

## Change-request Need lifecycle

Use one canonical `change_request` Need per change-request document, following
the shared method and starter. Status is draft for recorded intent, accepted
after actual owner approval, and implemented once agreed work is complete.
Keep the original request, scope, affected links and provenance in the Need;
keep dated review/implementation evidence centrally. Never infer requirement
acceptance or verification from CR status. Preserve stable IDs, old labels and
history when migrating ordinary records. Do not create a CR for a release
instruction; record that authorization in maturity.
''';p.write_text(t,encoding='utf-8')
print('Migrated 14 full CR records to canonical Needs; updated shared model, validator, method, templates and chart consumers.')
