Shared layout validation
========================================

Temporary template validation fixture, not project requirements.

.. toctree::
   :maxdepth: 2
   :caption: Scope management

   Change Requests <change-requests/index>
   Problem Tickets <problem-tickets/index>
   Project Metrics <project-metrics>

.. toctree::
   :maxdepth: 2
   :caption: Requirements

   requirements-stakeholder
   requirements-system
   requirements-software

.. toctree::
   :maxdepth: 2
   :caption: Architecture

   architecture-decisions
   architecture-system
   elements-system
   architecture-software
   elements-software
   state-machine
   technology-stack
   traceability

.. toctree::
   :maxdepth: 2
   :caption: Verification and Validation

   verification-plan
   test-cases/index
   test-scripts/index
   test-coverage
   test-execution/index

.. toctree::
   :maxdepth: 2
   :caption: Miscellaneous

   review
   maturity
   sources

.. toctree::
   :maxdepth: 2
   :caption: Utilities

   method
