Technology Stack
================

Temporary validation page.
