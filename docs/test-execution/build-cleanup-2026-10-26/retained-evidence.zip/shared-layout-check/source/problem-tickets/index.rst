Problem Tickets
===============

This is the canonical handover folder for user issues. Add a report named
``PRJ_PR_<NNN>.rst`` and keep screenshots/logs beside it. Start from
:download:`report.rst.template <report.rst.template>` or provide an informal
text report for the problem solver to normalize. Describe what happened, what
you expected and how to reproduce it when known; do not invent missing details.

Each normalized report contains one ``problem_report`` Need with a stable
project-prefixed ID. Status progresses from ``new`` to ``analyzed`` to ``fixed``.
Fixed reports remain here; owner review and release approval are separate.

.. status-pie:: problem_report

.. needtable::
   :filter: type == 'problem_report'
   :columns: id;title;status;verification_state

When the first report is normalized, add its page to a toctree here. Subsequent
reports join that same toctree; keep fixed reports in navigation. An empty new
project has no placeholder issues or unmatched glob entries.
