Architecture System
===================

Temporary validation page.
