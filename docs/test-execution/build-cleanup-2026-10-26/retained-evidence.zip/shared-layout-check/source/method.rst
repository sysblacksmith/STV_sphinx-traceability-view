Method
======

Temporary validation page.
