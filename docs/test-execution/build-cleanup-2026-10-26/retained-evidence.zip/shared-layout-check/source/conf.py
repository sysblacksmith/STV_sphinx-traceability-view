import sys
sys.path.insert(0, 'D:\\Dropbox\\MikroContr_Projects\\-agents\\skills\\reverse-engineer-requirements\\scripts')
from traceability_model import NEEDS_TYPES, NEEDS_LINKS, NEEDS_FIELDS
extensions=['sphinx_needs','status_charts','sphinx_rtd_theme']
project='Shared layout validation'
html_theme='sphinx_rtd_theme'
needs_types=NEEDS_TYPES
needs_links=NEEDS_LINKS
needs_fields=NEEDS_FIELDS
