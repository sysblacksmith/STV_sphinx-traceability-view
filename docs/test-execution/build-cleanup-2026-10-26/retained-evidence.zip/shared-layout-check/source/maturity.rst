Project maturity
=================

Current baseline and readiness
------------------------------

No maturity baseline or concept-review outcome has been recorded yet.
Record actual stakeholder/concept acceptance, implementation and verification
readiness here with decision evidence; do not infer them from a passing build.
Individual Need/ADR status remains authoritative on the artifact.

The generated status charts are in :doc:`project-metrics` under Scope management.

Review records
---------------

No concept review has been conducted yet. Add each actual round as a separate
RST file under a linked toctree here (or through a stable review index), with
assessed Need links, scope, authority, findings, revision identities and checks.
Keep history here and in those records rather than in unchanged artifacts.
