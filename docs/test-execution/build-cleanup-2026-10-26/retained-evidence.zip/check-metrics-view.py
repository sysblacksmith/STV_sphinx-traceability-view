"""Verify rendered chart populations, distinct SVGs and responsive display scaling."""
from collections import Counter
from pathlib import Path
import json
import math
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.support.ui import WebDriverWait

root=Path(__file__).resolve().parents[2]
output=root/'docs/_build/html'
needs=next(iter(json.loads((output/'needs.json').read_text())['versions'].values()))['needs'].values()
populations=[(kind,None) for kind in ('shr','sysr','swr','syse','swe')]+[('test_case',tag) for tag in ('test_system','test_software')]+[('problem_report',None),('change_request',None)]
options=webdriver.FirefoxOptions();options.add_argument('-headless')
options.set_preference('network.proxy.type',1)
options.set_preference('network.proxy.http','127.0.0.1');options.set_preference('network.proxy.http_port',9)
options.set_preference('network.proxy.ssl','127.0.0.1');options.set_preference('network.proxy.ssl_port',9)
results=[]
with webdriver.Firefox(service=Service('C:/Users/fragg/.cache/selenium/geckodriver/win64/0.37.1/geckodriver.exe'),options=options) as driver:
    for width in (1500,600):
        driver.set_window_size(width,1600)
        for page in ('project-metrics','problem-tickets/index'):
            driver.get((output/(page+'.html')).as_uri())
            WebDriverWait(driver,15).until(lambda d:d.execute_script("return [...document.querySelectorAll('img.status-pie-image')].every(i=>i.complete&&i.naturalWidth>0)"))
            charts=driver.find_elements('css selector','img.status-pie-image')
            assert len(charts)==(9 if page=='project-metrics' else 1)
            expected=populations if page=='project-metrics' else [('problem_report',None)]
            for chart,(kind,tag) in zip(charts,expected):
                counts=Counter(n['status'] for n in needs if n['type']==kind and (tag is None or tag in n['tags']))
                states=('new','analyzed','fixed') if kind=='problem_report' else ('draft','accepted','implemented') if kind=='change_request' else ('draft','reviewed','accepted')
                total=sum(counts.values())
                legend='; '.join(f'{s.capitalize()}: {counts[s]} ({100*counts[s]/total:.1f}%)' for s in states)
                assert chart.get_attribute('alt')==legend
                svg=(output/chart.get_dom_attribute('src')).read_text(encoding='utf-8') if page=='project-metrics' else (output/'problem-tickets'/chart.get_dom_attribute('src')).read_text(encoding='utf-8')
                for label in legend.split('; '):assert label in svg, (kind,tag,label)
            if page=='project-metrics':assert len({c.get_attribute('src') for c in charts})==9
            sizes=driver.execute_script("return [...document.querySelectorAll('img.status-pie-image')].map(i=>({width:i.getBoundingClientRect().width,height:i.getBoundingClientRect().height}))")
            driver.save_full_page_screenshot(str(root/f'docs/_build/{page.split("/")[0]}-{width}.png'))
            driver.execute_script("const s=document.createElement('style');s.textContent='img.status-pie-image{width:100%;max-width:614.4px}.requirement-status-card img.status-pie-image{width:100%;max-width:100%}';document.head.append(s)")
            baseline=driver.execute_script("return [...document.querySelectorAll('img.status-pie-image')].map(i=>({width:i.getBoundingClientRect().width,height:i.getBoundingClientRect().height}))")
            for actual,old in zip(sizes,baseline):
                assert abs(actual['width']/old['width']-.8)<.005
                assert abs(actual['height']/old['height']-.8)<.005
            assert driver.execute_script('return document.documentElement.scrollWidth<=window.innerWidth+1')
            results.append(dict(page=page,viewport=width,charts=len(charts),sizes=sizes,scale=.8))
(root/'docs/_build/metrics-view-check.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('Verified nine distinct population-correct metrics SVGs, the problem chart, and 80% width/height at desktop and narrow viewports.')
