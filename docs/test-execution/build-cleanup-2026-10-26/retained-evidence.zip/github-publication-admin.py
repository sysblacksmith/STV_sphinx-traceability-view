"""Local publication operations; never prints or persists credentials."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import urllib.error
import urllib.request

parser=argparse.ArgumentParser()
parser.add_argument('operation', choices=['preview','publish','visibility','pages','environment','protection','website'])
args=parser.parse_args()
root=Path(__file__).resolve().parents[2]
credentials=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',text=True,capture_output=True,check=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'))
values=dict(line.split('=',1) for line in credentials.stdout.splitlines() if '=' in line)
operations={
    'preview':('POST','/actions/workflows/pages.yml/dispatches',{'ref':'main','inputs':{'publish':False}}),
    'publish':('POST','/actions/workflows/pages.yml/dispatches',{'ref':'main','inputs':{'publish':True}}),
    'visibility':('PATCH','',{'visibility':'public'}),
    'pages':('POST','/pages',{'build_type':'workflow'}),
    'environment':('PUT','/environments/github-pages',{'deployment_branch_policy':{'protected_branches':True,'custom_branch_policies':False}}),
    'protection':('PUT','/branches/main/protection',json.loads((root/'.github/main-protection.json').read_text())),
    'website':('PATCH','',{'homepage':'https://sysblacksmith.github.io/STV_sphinx-traceability-view/'}),
}
method,endpoint,payload=operations[args.operation]
request=urllib.request.Request('https://api.github.com/repos/sysblacksmith/STV_sphinx-traceability-view'+endpoint,data=json.dumps(payload).encode(),method=method,headers={'Authorization':'Bearer '+values['password'],'Accept':'application/vnd.github+json','Content-Type':'application/json','X-GitHub-Api-Version':'2022-11-28'})
try:
    with urllib.request.urlopen(request,timeout=30) as response:
        content=response.read()
        result=json.loads(content) if content else {}
        print(json.dumps({'operation':args.operation,'status':response.status,**{key:result[key] for key in ('visibility','html_url','build_type','homepage') if key in result}}))
except urllib.error.HTTPError as error:
    body=json.load(error)
    print(json.dumps({'operation':args.operation,'status':error.code,'message':body.get('message'),'errors':body.get('errors')}))
    raise SystemExit(1)
