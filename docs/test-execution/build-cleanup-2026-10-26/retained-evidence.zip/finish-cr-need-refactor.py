from pathlib import Path
import re

root=Path(__file__).resolve().parents[2];shared=root.parent/'-agents'
for p in (root/'docs/change-requests').glob('STV_CR_*.rst'):
    t=p.read_text(encoding='utf-8');t=re.sub(r'(^   \.\. rubric::[^\n]+)\n(?=   \S)',r'\1\n\n',t,flags=re.M);p.write_text(t,encoding='utf-8')
p=shared/'skills/stakeholder-requirements-elicitor/SKILL.md';t=p.read_text(encoding='utf-8').replace('seven status charts','nine status charts');t+='\n\nCreate actual owner change records as `change_request` Needs using the shared\nmethod and starter, with draft/accepted/implemented lifecycle states. Keep\nordinary release authorization in maturity rather than making a release CR.\n';p.write_text(t,encoding='utf-8')
p=shared/'skills/reverse-engineer-requirements/scripts/test_validate_traceability.py';t=p.read_text(encoding='utf-8');at=t.index('    def add_test_case(self):')
t=t[:at]+'''    def test_change_requests_are_optional_and_use_their_own_lifecycle(self):
        for state in ('draft', 'accepted', 'implemented'):
            graph = copy.deepcopy(self.needs)
            graph['CR'] = dict(graph['SH'], id='CR', type='change_request',
                               status=state, derives_from=[], allocated_to=[])
            self.assertEqual(validate(backlinks(graph)), [])
        for state in ('reviewed', 'new', 'fixed', '', 'unclassified'):
            graph['CR']['status'] = state
            self.assertTrue(any('CR: invalid status' in e for e in validate(graph)))

    def test_change_request_cannot_replace_a_requirement_or_architecture(self):
        graph = copy.deepcopy(self.needs)
        graph['CR'] = dict(graph['SH'], id='CR', type='change_request', status='implemented')
        graph['SW']['derives_from'] = ['CR']
        self.assertTrue(any('illegal derives_from target CR' in e for e in validate(backlinks(graph))))
        graph['SW']['derives_from'] = ['SYS']
        graph['CR']['allocated_to'] = ['ELEMENT']
        self.assertTrue(any('CR: illegal allocated_to' in e for e in validate(backlinks(graph))))

    def test_implemented_is_not_a_requirement_review_state(self):
        self.needs['SH']['status'] = 'implemented'
        self.assertTrue(any('SH: invalid status' in e for e in validate(self.needs)))

'''+t[at:];p.write_text(t,encoding='utf-8')
print('Corrected rubric spacing and added CR lifecycle/typed-boundary regression checks.')
