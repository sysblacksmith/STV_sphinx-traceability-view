Additional generated-output cleanup
====================================

This is a proposal only. The previous approval covered different directories;
none of these 48 directories has been deleted. No active build/benchmark uses
them. Retained release records preserve results, timing, hashes and failures.

.. list-table:: Exact proposed directories
   :header-rows: 1
   :widths: 45 10 45

   * - Path
     - MiB
     - Reason / rebuild consequence
   * - ``docs/_build/.html-doctrees-0a3de7a6c8e141f38febe1af5dca472b``
     - 18.67
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-0ad8f8cce8f349b28d0b0cab5bc1ffdd``
     - 18.23
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-1561348d0e314d0a85afb9ac4b8c2ec9``
     - 20.28
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-3335392059084208acb215fe0685833f``
     - 16.07
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-33e168a5916b43afa555910ad2a46fe1``
     - 16.07
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-388c8160b18e4fa9913ceb29d9cffc6e``
     - 15.61
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-43d6c0eb1b994195b037a7869197b39a``
     - 15.60
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-4d459e36a57b4b18b61146032217b5fa``
     - 18.25
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-51e76ffe31784642abf46e7be8c60ed1``
     - 16.19
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-5a1117dc55854b498c32daa5a2cb7009``
     - 15.60
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-6bebbc0ff6fe4dca95063f90d07ceaa7``
     - 15.62
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-6de1dfa19f4e44cba1e60ba56d9e4c6e``
     - 16.28
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-6ef89ded6492497ea73228f1ca186f34``
     - 16.16
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-791f219fc2ae4ef68cf4fcef486fb10e``
     - 16.26
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-7bc631baef324fb8aae26f07e70bd6b7``
     - 16.26
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-7ccf849ec9ce48ab873b3f6cfa4a6362``
     - 16.25
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-81a4587719e04c6186ee0bbcdaf0cd39``
     - 15.60
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-833726d53c3640b3a87c27b31b7825a9``
     - 15.62
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-8584b8e43b304bb1b5e630c150fd8320``
     - 16.16
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-94e6391ee3f048d2a582378984a8926b``
     - 17.24
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-9a1b3968be574bd29b7a60cf2c41debe``
     - 16.24
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-9dbc22d3c9694f7493f6753e6bea3833``
     - 17.26
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-9fc80b74da924e929950434bc528afbc``
     - 16.26
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-a2a7d9402a08442c8e881436810ddb0d``
     - 16.25
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-a85f3b6e97534d2686d707747e3df899``
     - 16.07
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-a9ee088a43484a1d9657232ed408e8fd``
     - 18.23
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-afbb7badf7e241089d2145310014f402``
     - 15.81
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-b1a1aaef6a8741a78a6494c6b1c26ff4``
     - 15.82
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-bf84028a76e34aaeaeeec0f19f46adba``
     - 18.23
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-cdf8dfc73cf34531ba6f5fa804d4478f``
     - 16.25
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-dd63219905a646a0af60e694010f075c``
     - 16.19
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-ecc30a8ee6204d9dbd5c3d1508797e81``
     - 15.81
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-eeceac9757c246f599d2ff62a2e4cc6f``
     - 15.81
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-f3ae65e269334a9a88de537cb37b589d``
     - 16.19
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-doctrees-ff034963c05e4ad08f70bc5bfea61e80``
     - 16.20
     - Obsolete Sphinx caches; build_docs.py always creates a new UUID directory and uses a fresh -E -a build. None for the maintained build process; it never reuses these directories.
   * - ``docs/_build/.html-stage-2i4fww5p``
     - 48.12
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-7l4gzeey``
     - 47.65
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-8fqk43rg``
     - 51.59
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-a4oynz7b``
     - 49.84
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-b0ld5vou``
     - 49.89
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-czxk8oqw``
     - 40.60
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-fag414f8``
     - 41.19
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-i1mp4bbf``
     - 40.60
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-rgs1ce8m``
     - 52.89
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-riyva27k``
     - 49.48
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-wxvzkng6``
     - 51.84
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/.html-stage-z1lj4yz_``
     - 64.23
     - Abandoned generated documentation staging; failed build logs are retained and the embedded distribution has an identical retained original. Rebuild the corresponding documentation if inspection is needed; canonical source, logs, archives and current HTML remain.
   * - ``docs/_build/release-benchmark``
     - 1645.24
     - Generated 30,000-Need host fixtures and HTML; qualification is complete and no benchmark is active. Future capacity testing must regenerate a fixture (approximately 5?6 minutes per measured build); old --reuse-capacity-from paths cease to be available.

Total: 2.746 GiB.

Keep current HTML, all distributions and canonical release evidence, raw
capacity SVGs, development environments, wheelhouse and browser tools.
Other temporary preview/consumer trees are outside this approval and need
separate classification before removal.
