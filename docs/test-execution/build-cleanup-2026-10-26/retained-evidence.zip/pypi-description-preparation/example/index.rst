Traceability example
====================

.. shr:: Explore requirements
   :id: SH_001
   :traces: SW_001

   Readers can explore related requirements.

.. swr:: Render an interactive graph
   :id: SW_001

   The documentation contains a traceability view.

.. traceability-view:: SH_001