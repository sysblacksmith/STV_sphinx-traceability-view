﻿from pathlib import Path
import subprocess,sys,tarfile,zipfile,json,hashlib,os
from email.parser import BytesParser
from docutils.core import publish_doctree
from docutils import nodes
root=Path.cwd();base=root/'docs/_build/pypi-description-preparation';out=base/'final';description=(root/'PYPI.rst').read_text(encoding='utf-8')
wheel=out/'sphinx_traceability_view-1.0.0-py3-none-any.whl';sdist=out/'sphinx_traceability_view-1.0.0.tar.gz'
def check(data):
 m=BytesParser().parsebytes(data);assert m['Version']=='1.0.0';assert m['Description-Content-Type']=='text/x-rst';assert m.get_payload().strip()==description.strip();assert len(m.get_all('Project-URL'))==3
with zipfile.ZipFile(wheel) as z:check(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
with tarfile.open(sdist) as t:
 check(t.extractfile(next(n for n in t.getnames() if n.endswith('/PKG-INFO'))).read());assert t.extractfile(next(n for n in t.getnames() if n.endswith('/PYPI.rst'))).read().decode('utf-8').strip()==description.strip();t.extractall(base/'source',filter='data')
source=base/'source/sphinx_traceability_view-1.0.0'
subprocess.run([sys.executable,'-m','build','--wheel','--no-isolation','--outdir',str(base/'rebuilt'),str(source)],check=True)
with zipfile.ZipFile(next((base/'rebuilt').glob('*.whl'))) as z:check(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
envdir=base/'consumer';subprocess.run([sys.executable,'-m','venv',str(envdir)],check=True)
python=envdir/'Scripts/python.exe';wheelhouse=root/'docs/_build/wheelhouse'
subprocess.run([str(python),'-m','pip','install','--no-index','--find-links',str(wheelhouse),'-r',str(root/'requirements-tooling.txt'),str(wheel)],check=True,stdout=subprocess.DEVNULL)
blocks=[n.astext() for n in publish_doctree(description).findall(nodes.literal_block)]
docs=base/'example';docs.mkdir()
(docs/'conf.py').write_text(next(b for b in blocks if b.startswith('project =')),encoding='utf-8')
(docs/'index.rst').write_text(next(b for b in blocks if b.startswith('Traceability example')),encoding='utf-8')
env=dict(os.environ);env.pop('PYTHONPATH',None);env['PATH']=str(envdir/'Scripts')+os.pathsep+str(Path(os.environ['SystemRoot'])/'System32')
subprocess.run([str(python),'-m','sphinx','-E','-a','-W','-b','html',str(docs),str(base/'example-html')],check=True,cwd=base,env=env)
html=(base/'example-html/index.html').read_text(encoding='utf-8');assert 'STV_PENDING' not in html;assert 'data-stv-' in html
old=json.loads((base/'existing-dist-sha256.json').read_text());assert all(hashlib.sha256((root/'dist'/n).read_bytes()).hexdigest()==h for n,h in old.items())
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (wheel,sdist)};(base/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in hashes.items()),encoding='utf-8')
print('Metadata, sdist rebuild, installed README example and original dist preservation: PASSED');print(json.dumps(hashes,indent=2))
