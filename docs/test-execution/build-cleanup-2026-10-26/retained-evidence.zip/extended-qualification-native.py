﻿from pathlib import Path
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
import sys,os,time,json
root=Path.cwd();out=root/'docs/_build/extended-qualification';out.mkdir(exist_ok=True);(out/'chosen-folder').mkdir(exist_ok=True)
sys.path.insert(0,str(root/'docs/test-scripts'));from test_browser import published_url
options=Options();options.set_preference('browser.download.useDownloadDir',False);options.set_preference('browser.download.folderList',2);options.set_preference('browser.download.dir',str(out/'chosen-folder'));options.set_preference('browser.shell.checkDefaultBrowser',False);options.set_preference('browser.startup.homepage_override.mstone','ignore');options.set_preference('network.proxy.type',1);options.set_preference('network.proxy.http','127.0.0.1');options.set_preference('network.proxy.http_port',9);options.set_preference('network.proxy.ssl','127.0.0.1');options.set_preference('network.proxy.ssl_port',9);options.set_preference('network.proxy.no_proxies_on','localhost,127.0.0.1')
driver=webdriver.Firefox(options=options,service=Service(r'C:/Users/fragg/.cache/selenium/geckodriver/win64/0.37.1/geckodriver.exe'))
try:
 driver.set_window_size(1500,1100)
 with published_url(root/'docs/_build/html','http') as url:
  file=(root/'docs/_build/html/demo.html').as_uri();http=url.replace('index.html','demo.html');driver.get(file)
  (out/'native-session.json').write_text(json.dumps(dict(file_url=file,http_url=http,browser=driver.capabilities['browserVersion'],profile_scope='Isolated temporary WebDriver profile; always ask location; outbound proxy blocked',chosen_directory=str(out/'chosen-folder')),indent=2),encoding='utf-8');print('Native session ready',flush=True)
  while not(out/'native-session-finished').exists():time.sleep(1)
finally:driver.quit()
