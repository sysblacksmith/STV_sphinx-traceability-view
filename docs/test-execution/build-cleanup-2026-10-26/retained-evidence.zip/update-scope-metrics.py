from pathlib import Path
import re

root=Path(__file__).resolve().parents[2]
shared=root.parent/'-agents'
renderer=shared/'skills/reverse-engineer-requirements/scripts/status_charts.py'
t=renderer.read_text(encoding='utf-8')
t=t.replace('from hashlib import sha256\n','from hashlib import sha256\nfrom pathlib import PurePosixPath\nimport re\n',1)
t=t.replace('from sphinx.util.docutils import SphinxDirective\n','from sphinx.util.docutils import SphinxDirective\nfrom sphinx.errors import SphinxError\n',1)
at=t.index('\n\nclass StatusPie(')
t=t[:at]+'''

CHANGE_REQUEST_STATES = ['draft', 'accepted', 'implemented', 'unclassified']


def change_request_counts(app):
    """Read ordinary CR document metadata; do not create synthetic Needs."""
    root = app.config.status_chart_change_request_root.strip('/')
    counts = Counter()
    identities = set()
    for docname in sorted(app.env.found_docs):
        path = PurePosixPath(docname)
        if str(path.parent) != root:
            continue
        match = re.match(r'^(.+_CR_[0-9]+)(?:_|$)', path.name)
        if not match:
            continue
        identity = match[1]
        if identity in identities:
            raise SphinxError(f'Duplicate change request {identity} in {root}')
        identities.add(identity)
        status = app.env.metadata.get(docname, {}).get('change_request_status', 'unclassified').strip()
        if status not in CHANGE_REQUEST_STATES:
            raise SphinxError(f'{docname}: invalid change_request_status {status!r}; use draft, accepted or implemented')
        counts[status] += 1
    return counts
''' +t[at:]
t=t.replace('class StatusPieDirective(SphinxDirective):','class StatusTotal(nodes.General, nodes.Element):\n    pass\n\n\nclass StatusPieDirective(SphinxDirective):',1)
t=t.replace("if kind not in NEEDS_STATUSES_BY_TYPE:","if kind not in NEEDS_STATUSES_BY_TYPE and kind != 'change_request':",1)
t=t.replace("        node = StatusPie(kind=kind, tag=self.options.get('tag'))", "        if kind == 'change_request' and 'tag' in self.options:\n            raise self.error('Change-request status charts do not support Need tags')\n        node = self.node_type(kind=kind, tag=self.options.get('tag'))",1)
t=t.replace('    required_arguments = 1\n','    node_type = StatusPie\n    required_arguments = 1\n',1)
t=t.replace('\n\ndef render_status_charts', '\n\nclass StatusTotalDirective(StatusPieDirective):\n    node_type = StatusTotal\n\n\ndef render_status_charts',1)
t=t.replace('charts = list(doctree.findall(StatusPie))','charts = list(doctree.findall(lambda node: isinstance(node, (StatusPie, StatusTotal))))',1)
t=t.replace("        statuses = NEEDS_STATUSES_BY_TYPE[kind]\n        tag = node.get('tag')\n        counts = Counter(need['status'] for need in needs.values()\n                         if need['type'] == kind\n                         and (tag is None or tag in need.get('tags', [])))", "        tag = node.get('tag')\n        if kind == 'change_request':\n            statuses = CHANGE_REQUEST_STATES\n            counts = change_request_counts(app)\n        else:\n            statuses = NEEDS_STATUSES_BY_TYPE[kind]\n            counts = Counter(need['status'] for need in needs.values()\n                             if need['type'] == kind\n                             and (tag is None or tag in need.get('tags', [])))",1)
t=t.replace('        total = sum(counts.values())\n','        total = sum(counts.values())\n        if isinstance(node, StatusTotal):\n            node.replace_self(nodes.paragraph(text=f"Total: {total}"))\n            continue\n',1)
t=t.replace('        colors = [palette.get(state,', "        active_palette = dict(palette, accepted='#4C91C7', implemented='#56A477', unclassified='#888888') if kind == 'change_request' else palette\n        colors = [active_palette.get(state,",1)
t=t.replace("    app.add_directive('status-pie', StatusPieDirective)","    app.add_directive('status-pie', StatusPieDirective)\n    app.add_directive('status-total', StatusTotalDirective)\n    app.add_config_value('status_chart_change_request_root', 'change-requests', 'env', types=[str])",1)
renderer.write_text(t,encoding='utf-8')

section='''
Scope management status
------------------------

Problem tickets use their New / Analyzed / Fixed lifecycle. Change requests
use Draft / Accepted / Implemented metadata on their source documents;
Unclassified identifies records without explicit status. These lifecycles
do not change requirement acceptance or verification results.

.. container:: requirement-status-charts scope-status-charts

   .. container:: requirement-status-card

      **Problem tickets**

      .. status-pie:: problem_report

      **Total:** :need_count:`type == 'problem_report'`

   .. container:: requirement-status-card

      **Change requests**

      .. status-pie:: change_request

      .. status-total:: change_request
'''
for p in (root/'docs/project-metrics.rst',shared/'skills/reverse-engineer-requirements/assets/sphinx/project-metrics.rst'):
    t=p.read_text(encoding='utf-8');assert 'Scope management status' not in t;p.write_text(t.rstrip()+'\n'+section,encoding='utf-8')

# The existing accepted/released scope and retained implementation records
# establish completion of CR001-014; no requirement/test status is changed.
for p in (root/'docs/change-requests').glob('STV_CR_*.rst'):
    t=p.read_text(encoding='utf-8');assert ':change_request_status:' not in t
    lines=t.splitlines(keepends=True)
    for i,line in enumerate(lines):
        if i and re.fullmatch(r'=+\s*',line) and lines[i-1].strip():
            lines.insert(i+1,'\n:change_request_status: implemented\n');break
    else:raise ValueError(p)
    p.write_text(''.join(lines),encoding='utf-8')

guidance='''

## Scope-management metrics and change-request status

Metrics contains nine charts: the seven requirement/element/test-case charts
plus a **Scope management status** subsection with problem tickets and change
requests. Use `status-pie:: problem_report` and its matching `need_count` total.
Problem report states remain new/analyzed/fixed.

Change requests remain ordinary RST records, not a new Sphinx-Needs type.
Immediately after the document title, use a document metadata field:
`:change_request_status: draft`. Allowed author-maintained values are `draft`,
`accepted`, and `implemented`: recorded/proposed intent, owner-approved request,
and completed agreed work respectively. Implementation status does not imply
requirement acceptance, full verification or release approval. Keep dated
decision/evidence history in maturity/review records; preserve historical prose.
Migrate existing records only from actual acceptance/implementation evidence.

Use `status-pie:: change_request` and `status-total:: change_request` in the
metrics card. Both read the same Sphinx document metadata population: direct
children of `change-requests/` matching `<PROJECT>_CR_<number>[_<slug>]`.
Override `status_chart_change_request_root` only for an established alternate
folder. Indexes, attachments with other names, excluded sources and stashed
files are not records. Duplicate IDs and invalid statuses fail the build.
Missing metadata is shown as **Unclassified**, never guessed from prose or
silently omitted. All four legend states include zero counts and percentages;
an empty population displays the existing no-data message and a zero total.
CR colors use gold for Draft, blue for Accepted, green for Implemented and grey
for Unclassified, reflecting request progress independently of Need review state.
Tagged populations use distinct, safe SVG filenames so one chart cannot
overwrite another. All nine metric charts and the independent problem-index
chart retain the shared 80% display scaling and responsive layout.
'''
p=shared/'skills/reverse-engineer-requirements/references/documentation-layout.md';t=p.read_text(encoding='utf-8').replace('Seven status charts under Scope management','Nine status charts under Scope management');t=t.replace('Place seven generated charts','Place nine generated charts').replace('All seven charts have','All nine charts have').replace('Check all seven charts','Check all nine charts');p.write_text(t.rstrip()+guidance,encoding='utf-8')
p=shared/'method.md';t=p.read_text(encoding='utf-8').replace('seven generated status charts','nine generated status charts').replace('seven status-chart dashboard','nine status-chart dashboard');t+='\n\n## Change-request lifecycle metrics\n\nChange requests remain ordinary RST documents. Their explicit document metadata\n`change_request_status` uses draft, accepted or implemented, independently of\nNeed acceptance and verification. Draft records proposed/recorded intent; accepted\nrecords owner approval; implemented records completion of the agreed work.\nMissing values are visible as Unclassified. The Metrics scope-management\nsubsection charts these records and the independent new/analyzed/fixed problem\nreports, following the shared documentation-layout reference. Do not infer status\nfrom keywords, passing tests or release creation, and do not create a CR for an\nordinary release instruction. Keep current CR status in its metadata and dated\nacceptance/implementation evidence in the central maturity/review records.\n';p.write_text(t,encoding='utf-8')
p=shared/'skills/reverse-engineer-requirements/assets/sphinx/change-requests/index.rst';t=p.read_text(encoding='utf-8');t+='\nUse ``:change_request_status: draft`` as document metadata immediately after\neach new request title. Update to ``accepted`` on owner approval and\n``implemented`` when the agreed work is complete; keep decision evidence in\nthe maturity/review records. These statuses feed :doc:`../project-metrics`.\n';p.write_text(t,encoding='utf-8')
p=shared/'skills/manage-change/SKILL.md';t=p.read_text(encoding='utf-8');t+='\n\n## Change-request lifecycle metadata\n\nUse the shared method and layout\'s ordinary-document `change_request_status`\nmetadata: draft for recorded intent, accepted after actual owner approval, and\nimplemented after the agreed work is complete. Preserve dated evidence centrally.\nDo not create a Sphinx-Needs CR type or infer acceptance/verification from the\nMetrics chart. Ordinary release instructions belong in maturity, not the CR register.\n';p.write_text(t,encoding='utf-8')
print('Updated shared charts, templates, lifecycle guidance and 14 STV CR metadata fields.')
