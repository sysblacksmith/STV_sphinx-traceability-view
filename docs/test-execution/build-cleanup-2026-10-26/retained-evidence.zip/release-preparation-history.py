"""Record the owner's 2026-10-24 scoped acceptance and private release instruction."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def append(name, text):
    path = ROOT / name
    previous = path.read_text(encoding="utf-8")
    if text.strip() not in previous:
        path.write_text(previous + text, encoding="utf-8")

for name, identities in (
    ('system-tests.rst', ['STV_TC_SY_038'] + [f'STV_TC_SY_{i:03}' for i in range(47, 55)]),
    ('software-tests.rst', [f'STV_TC_SW_{i:03}' for i in range(40, 43)]),
):
    path = ROOT / 'docs/test-cases' / name
    text = path.read_text(encoding='utf-8')
    for identity in identities:
        text, count = re.subn(r'(:id: ' + identity + r'\s*\n\s*:status:) (?:draft|accepted)', r'\1 accepted', text)
        assert count == 1, identity
    path.write_text(text, encoding='utf-8')

append('docs/change-requests/index.rst', '\n   STV_CR_015_private-1-0-0-release\n')
append('docs/review.rst', '''
Private release acceptance
----------------------------

On 2026-10-24 the owner approved PRSA-001 through PRSA-005 and final PR015
presentation. :doc:`concept-reviews/round-14` records the scoped acceptance;
:ref:`STV_CR_015` authorizes private v1.0.0 with runner/hosted work deferred.
''')
append('docs/sources.rst', '''
Private release instruction, 2026-10-24
----------------------------------------

Owner conversation: "ok, i give my go for number 1 and 2. 3 and 4 remain for
later. right now i want to release v1.0.0 without setting the repo to public,
yet." Numbering refers to the preceding readiness assessment. See
:ref:`STV_CR_015` and :doc:`concept-reviews/round-14`.
''')
append('docs/concept-reviews/round-13.rst', '''
Owner acceptance
------------------

The owner explicitly approved readiness item 2 on 2026-10-24, accepting this
final presentation and pane-frame follow-up. :doc:`round-14` records the
decision. Earlier pending-owner statements above remain historical. No new
manual retest execution is inferred.
''')
path = ROOT / 'docs/maturity.rst'
text = path.read_text(encoding='utf-8')
heading = 'Private v1.0.0 release authorized'
if heading not in text:
    at = text.index('PR014 visible')
    text = text[:at] + '''Private v1.0.0 release authorized
-----------------------------------

The owner approved PRSA-001 through PRSA-005 remediation and PR015 final
presentation on 2026-10-24. See :doc:`concept-reviews/round-14` and
:doc:`change-requests/STV_CR_015_private-1-0-0-release`. Earlier pending-owner
statements below are historical and superseded for this exact scope.
The owner requests v1.0.0 while keeping the repository private. Runner
improvements and hosted hardening are deferred; PRSA-006 remains open.
New full local qualification is required; no completed release is claimed yet.

''' + text[at:]
    text = text.replace('   concept-review\n', '   concept-review\n   concept-reviews/round-14\n', 1)
    path.write_text(text, encoding='utf-8')
path = ROOT / 'docs/change-requests/STV_CR_015_private-1-0-0-release.rst'
text = path.read_text(encoding='utf-8')
if not text.startswith('.. _STV_CR_015:'):
    path.write_text('.. _STV_CR_015:\n\n' + text, encoding='utf-8')
path = ROOT / 'src/sphinx_traceability_view/_version.py'
text = path.read_text(encoding='utf-8')
path.write_text(text.replace('1.0.0.dev0', '1.0.0'), encoding='utf-8')
print('Scoped owner acceptance and private release version recorded.')
