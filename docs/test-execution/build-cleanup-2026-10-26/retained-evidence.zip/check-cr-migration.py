from pathlib import Path
import json,re,subprocess
from bs4 import BeautifulSoup

root=Path(__file__).resolve().parents[2];html=root/'docs/_build/html'
def body(text, migrated=False):
    lines=text.splitlines()
    if migrated:
        start=next(i for i,line in enumerate(lines) if ':verification_state:' in line)+1
        lines=[line[3:] if line.startswith('   ') else line for line in lines[start:]]
    else:
        start=next(i for i,line in enumerate(lines) if i and re.fullmatch('=+',line) and lines[i-1].strip())+1
        lines=lines[start:]
    return [re.sub(r'^\.\. rubric:: ','',line.strip()) for line in lines if line.strip() and not re.fullmatch(r'[-=~^]{3,}',line.strip())]
for path in (root/'docs/change-requests').glob('STV_CR_*.rst'):
    old=subprocess.check_output(['git','show','HEAD:'+path.relative_to(root).as_posix()],cwd=root).decode('utf-8')
    assert body(old)==body(path.read_text(encoding='utf-8'),True),path
data=next(iter(json.loads((html/'needs.json').read_text())['versions'].values()))['needs']
crs=[n for n in data.values() if n['type']=='change_request']
assert len(crs)==14 and {n['id'] for n in crs}=={f'STV_CR_{i:03}' for i in range(1,15)}
assert all(n['status']=='implemented' and n['verification_state']=='not_assessed' for n in crs)
old_needs=None
for path in sorted((root/'docs/_build').glob('.html-previous-*/needs.json'),key=lambda p:p.stat().st_mtime,reverse=True):
    candidate=next(iter(json.loads(path.read_text())['versions'].values()))['needs']
    if len(candidate)==1193:
        old_needs=candidate;break
assert old_needs is not None
fields=('status','verification_state','last_result','result','executed_at','verifies','executed_by','derives_from','allocated_to','part_of')
for identity,record in old_needs.items():
    for field in fields:assert record.get(field)==data[identity].get(field),(identity,field)
page=BeautifulSoup((html/'project-metrics.html').read_text(encoding='utf-8'),'html.parser')
images=page.select('img.status-pie-image');assert len(images)==9
assert images[-1]['alt']=='Draft: 0 (0.0%); Accepted: 0 (0.0%); Implemented: 14 (100.0%)'
assert images[-2]['alt']=='New: 0 (0.0%); Analyzed: 1 (6.7%); Fixed: 14 (93.3%)'
assert len({i['src'] for i in images})==9
for image in images:
    svg=(html/image['src']).read_text(encoding='utf-8')
    for label in image['alt'].split('; '):assert label in svg
print('All 14 CR IDs/prose preserved; 1,193 prior records retain statuses/verification/relations; all nine chart legends match distinct SVGs.')
