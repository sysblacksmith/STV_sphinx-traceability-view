from pathlib import Path
import hashlib,json,re,subprocess,sys,xml.etree.ElementTree as ET
from datetime import datetime,timezone
exec(Path('docs/_build/cr014-map.py').read_text(encoding='utf-8-sig').split("for report in ['node.xml'")[0])
record=root/'docs/test-execution/pr015-details'
reports=['node.xml','python.xml','focused.xml','adjacent.xml']
rows=[];groups={};failed=[];canonical=set()
for source in (root/'docs/test-cases').glob('*.rst'):canonical.update(re.findall(r'^   :id: (STV_TC_\S+)',source.read_text(),re.M))
def finish(p):return datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat()
def outcome(c):return 'failed' if c.find('failure') is not None or c.find('error') is not None else 'skipped' if c.find('skipped') is not None else 'passed'
for report in reports:
 p=record/report
 for c in ET.parse(p).findall('.//testcase'):
  name=c.get('name');id=byname.get(name)
  if name.startswith('test_detail_metadata_controls_'):id='STV_TC_SY_065'
  elif c.get('file','').endswith('stability.test.js'):id='STV_TC_SW_045' if 'STV_SWR_060:' in name else 'STV_TC_SW_043'
  elif c.get('file','').endswith('edge-viewport.test.js'):id='STV_TC_SW_044'
  elif c.get('file','').endswith('classified-rows.test.js'):id='STV_TC_SW_048'
  elif name.startswith('test_viewport_boundary_tracks_clipping_and_controls'):id='STV_TC_SY_062'
  elif name.startswith('STV_SWR_063:'):id='STV_TC_SW_049'
  elif name.startswith(('test_details_limit_','test_persistent_limit_is_published')):id='STV_TC_SW_050'
  elif name.startswith('test_persistent_stack_fifo'):id='STV_TC_SY_063'
  elif name.startswith('test_persistent_completion_identity'):id='STV_TC_SY_064'
  assert id in canonical,(report,name,id)
  item=dict(case_id=id,selector=c.get('classname','')+' :: '+name,result=outcome(c),report=report,report_completed_at=finish(p))
  rows.append(item)
  if item['result']!='passed':failed.append(item)
  else:groups.setdefault(id,[]).append(item)
assert not (record/'cases.rst').exists(),'Do not overwrite execution history'
lines=['PR015 canonical development executions','='*60,'','Each record aggregates a complete canonical procedure. Raw runner subtests and','enclosing report completion times are retained; no individual finish times are invented.','Source/artifact identity and phase notes are in :doc:`index`. This is development','verification and does not qualify a release.','']
links={}
def emit(id,items,label):
 identity='STV_TE_'+hashlib.sha256(('pr015-details:'+id+':'+label).encode()).hexdigest()[:16].upper();result='passed' if all(x['result']=='passed' for x in items) else 'failed';stamp=max(x['report_completed_at'] for x in items)
 for item in items:item['execution_id']=identity
 refs=sorted({x['report'] for x in items})
 lines.extend(['.. test_execution:: '+id+' '+label,'   :id: '+identity,'   :status: recorded','   :basis: observed','   :evidence: docs/test-execution/pr015-details/'+refs[0],'   :priority: unassigned','   :verification_state: not_assessed','   :result: '+result,'   :executed_at: '+stamp,'','   **Case:** :need:`'+id+'`. '+str(len(items))+' actual runner outcomes; '+result+'.','   :download:`Subtest mapping <case-results.json>` retains exact selections.','   Reports: '+', '.join(':download:`'+r+' <'+r+'>`' for r in refs)+'.',''])
 links.setdefault(id,[]).append(identity)
 return result
# Preserve the pre-fix attempt as its own complete two-protocol execution.
items=[];p=record/'before.xml'
for c in ET.parse(p).findall('.//testcase'):
 items.append(dict(case_id='STV_TC_SY_065',selector=c.get('classname','')+' :: '+c.get('name'),result=outcome(c),report='before.xml',report_completed_at=finish(p)))
emit('STV_TC_SY_065',items,'before acceptance correction');rows.extend(items)
for item in failed:emit(item['case_id'],[item],item['report']+' failed fixture attempt')
for id,items in sorted(groups.items()):emit(id,items,'complete development procedure')
(record/'cases.rst').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(record/'case-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for source in (root/'docs/test-cases').glob('*.rst'):
 blocks=re.split(r'(?=^\.\. test_case::)',source.read_text(encoding='utf-8'),flags=re.M)
 for i,block in enumerate(blocks):
  m=re.search(r'^   :id: (STV_TC_\S+)',block,re.M)
  if not m or m[1] not in groups:continue
  id=m[1];block=re.sub(r'(:last_result:) \S+',r'\1 passed',block)
  if ':executed_by:' in block:block=re.sub(r'(:executed_by: [^\n]+)',lambda m:m[0]+', '+', '.join(links[id]),block)
  else:block=block.replace('   :last_result:','   :executed_by: '+', '.join(links[id])+'\n   :last_result:')
  blocks[i]=block
 source.write_text(''.join(blocks),encoding='utf-8')
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines()
identity={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'version':'1.0.0.dev0','python':sys.version,'node':subprocess.check_output(['node','--version'],text=True).strip(),'browser':'Firefox 158.0.1','geckodriver':'0.37.1','os':'Windows 11','source_sha256':{},'artifacts':{},'notes':'Dirty development worktree; no release. Product code unchanged across retained successful suites. Acceptance corrections over the prior dirty CR014 worktree; updated presentation criteria and actual retained attempts are recorded in index.rst.'}
for name in files:
 p=root/name
 if p.is_file() and not name.startswith(('docs/test-execution/','docs/_build/')):identity['source_sha256'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in (root/'docs/_build/pr015-dist').glob('*'):identity['artifacts'][p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(record/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(len(groups),'canonical complete procedures; missing current cases',sorted(canonical-groups.keys()))

