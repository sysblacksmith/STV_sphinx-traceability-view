﻿from pathlib import Path
import re,json,xml.etree.ElementTree as ET
root=Path('.'); record=root/'docs/test-execution/cr014-details'
# Map framework names using canonical selectors and retained historical mappings.
byname={}
for p in (root/'docs/test-cases').glob('*.rst'):
 for block in re.split(r'(?=^\.\. test_case::)',p.read_text(encoding='utf-8'),flags=re.M)[1:]:
  id=re.search(r'^   :id: (\S+)',block,re.M)[1]
  m=re.search(r'\*\*Executable selector:\*\* ``([^`]+)``',block)
  if m:byname[m[1].rsplit('::',1)[-1].rsplit(' :: ',1)[-1].strip()]=id
for p in (root/'docs/test-execution').glob('*/case-results.json'):
 if p.parent==record:continue
 try:items=json.loads(p.read_text(encoding='utf-8-sig'))
 except (ValueError,UnicodeError):continue
 if not isinstance(items,list):continue
 for item in items:
  selector=item.get('selector','');id=item.get('case_id')
  if selector and id:byname.setdefault(selector.rsplit(' :: ',1)[-1].rsplit('::',1)[-1].strip(),id)
for report in ['node.xml','python.xml','focused-final.xml','browser-regression.xml','capacity.xml']:
 p=record/report
 if not p.exists():print('PENDING',report);continue
 items=ET.parse(p).findall('.//testcase');unmapped=[]
 for c in items:
  name=c.get('name');id=byname.get(name)
  if name.startswith('STV_SWR_063:'):id='STV_TC_SW_049'
  elif name.startswith(('test_details_limit_','test_persistent_limit_is_published')):id='STV_TC_SW_050'
  elif name.startswith('test_persistent_stack_fifo'):id='STV_TC_SY_063'
  elif name.startswith('test_persistent_completion_identity'):id='STV_TC_SY_064'
  if not id:unmapped.append(name)
 print(report,len(items),'unmapped',unmapped)

