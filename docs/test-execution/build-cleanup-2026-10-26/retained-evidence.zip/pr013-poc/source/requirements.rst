Requirements
============

.. shr:: Parent P
   :id: P
   :traces: A, B, C, D, E

   Parent content.

.. shr:: Parent Q
   :id: Q
   :traces: F

   Parent content.

.. swr:: Child A
   :id: A

   Child content.

.. swr:: Child B
   :id: B

   Child content.

.. swr:: Child C
   :id: C

   Child content.

.. swr:: Child D
   :id: D

   Child content.

.. swr:: Child E
   :id: E

   Child content.

.. swr:: Child F
   :id: F

   Child content.

