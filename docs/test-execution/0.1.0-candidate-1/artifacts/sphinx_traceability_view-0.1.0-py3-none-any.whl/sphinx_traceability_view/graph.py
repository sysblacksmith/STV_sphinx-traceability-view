"""Adapt the completed NeedsView into deterministic, bidirectional graph data."""


def snapshot(needs, model, uri, project):
    records = list(needs.to_list_with_parts())
    hidden = {n.get("id_complete", n["id"]) for n in records if n.get("hide")}
    hidden.update(n.get("id_complete", n["id"]) for n in records if n.get("id_parent") in hidden)
    objects = {}
    for n in records:
        identity = n.get("id_complete", n["id"])
        if identity in hidden:
            continue
        original = n.get("external_url") if n.get("is_external") else uri(n["docname"]) + "#" + identity
        objects[identity] = {"id": identity, "title": n.get("title", n.get("content", "")),
                             "type": n["type"], "status": n.get("status") or "",
                             "url": original, "docname": n.get("docname"),
                             "parent": n.get("id_parent") if n.get("is_part") else None,
                             "external": bool(n.get("is_external"))}
        if n.get("is_external"):
            excluded = set(model["relations"]) | {name + "_back" for name in model["relations"]}
            objects[identity]["metadata"] = {key: value for key, value in n.items()
                if key not in excluded and isinstance(value, (str, int, float, bool, list, type(None)))}
    edges = set()
    for n in records:
        source = n.get("id_complete", n["id"])
        if source not in objects:
            continue
        for relation in model["relations"]:
            for target in n.get(relation, []):
                if target not in hidden:
                    edges.add((source, relation, target))
    adjacency = {i: {"incoming": {}, "outgoing": {}} for i in objects}
    for source, relation, target in sorted(edges):
        adjacency[source]["outgoing"].setdefault(relation, []).append(target)
        if target in objects:
            adjacency[target]["incoming"].setdefault(relation, []).append(source)
    return {"schema": 1, "project": project, "model": model,
            "objects": dict(sorted(objects.items())), "edges": sorted(edges), "adjacency": adjacency,
            "entries": sorted(i for i, n in objects.items() if not n["parent"] and model["types"][n["type"]].get("role") == "stakeholder")}, hidden
